import cv2
import matplotlib.pyplot as plt
from tkinter import *
import numpy as np
from keras.preprocessing.image import array_to_img
from PIL import Image
import scipy
import ImageTk
from vgg19 import *
from aug_data import dataProcess
from scipy import misc, var

if __name__ == "__main__":
    root = Tk()
    root.title("U-NET")  # 设置窗口标题
    canvas = Canvas(root,
                            width=950,  # 指定Canvas组件的宽度
                            height=650,  # 指定Canvas组件的高度
                            bg='white')
    # root.resizable(0, 0)
    # root.geometry("500x500")
    # root.update()
    image = Image.open('E:/code/retina/UNet.png')
    im = ImageTk.PhotoImage(image)
    canvas.create_image(490, 360, image=im)
    canvas.create_text(450, 80,  # 使用create_text方法在坐标（302，77）处绘制文字
                       text='U-Net模型结构图'  # 所绘制文字的内容
                       , fill='gray')  # 所绘制文字的颜色为灰色
    canvas.pack()  # 将Canvas添加到主窗口

    #function to be called when mouse is clicked
    def printcoords():
        # File = filedialog.askopenfilename(parent=root, initialdir="E:/code/retina/image/",title='Choose an image.')
        # filename = ImageTk.PhotoImage(Image.open(File))
        # canvas.image = filename  # <--- keep reference of your image
        # canvas.create_image(10,10,anchor='nw',image=filename)
        # print('File',File)
        # print('filename',filename)
        n = int(entry.get())
        # print(n)

        mask = Image.open('E:/code/retina/mask.tif').convert('L')
        mask_arr = np.array(mask)
        mask_otsu = np.zeros([512, 512])
        [rows, cols] = mask_arr.shape
        for i in range(rows - 1):
            for j in range(cols - 1):
                if mask_arr[i, j] > 125:
                    mask_otsu[i, j] = 255
        kernel = np.ones((7, 7), np.uint8)
        mask_otsu = cv2.erode(mask_otsu, kernel, iterations=2)
        # mydata = dataProcess(512, 512)
        # img_test = mydata.load_test_data()
        #
        # myunet = Vgg19()
        # model = myunet.get_unet()
        # model.load_weights('unet.hdf5')
        # imgs_mask_test = model.predict(img_test, batch_size=1, verbose=1)

        # np.save('imgs_mask_test.npy', imgs_mask_test)
        imgs_test_predict = np.load('imgs_mask_test.npy')
        # print(img_test.shape, imgs_test_predict.shape)

        img1 = imgs_test_predict[n]
        img1 = array_to_img(img1)
        img_arr = np.array(img1)

        for i in range(rows - 1):
            for j in range(cols - 1):
                if mask_otsu[i, j] == 0:
                    img_arr[i, j] = 0
        # photo = PhotoImage(file='n.gif')
        # imgLabel = Label(root, image=photo)
        # imgLabel.pack(side=RIGHT)
        plt.gray()
        plt.imshow(img_arr)
        plt.title("Retinal vessel segmentation")
        plt.axis('off')
        plt.show()
        scipy.misc.imsave('n.tif', img_arr)


    e = StringVar()
    entry = Entry(root,
                  text='input image number here'
                  )
    entry.pack()
    # entry.bind('<Button-1>', Button)
    Button(root,text='确定',command=printcoords).pack(side=TOP)
    root.mainloop()
