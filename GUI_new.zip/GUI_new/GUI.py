# !/usr/bin/python
# -*- coding: UTF-8 -*-
from tkinter import *
import tkinter.messagebox
import cv2
import matplotlib.pyplot as plt
from tkinter import *
import numpy as np
from keras.preprocessing.image import array_to_img
from PIL import Image
import scipy
import ImageTk
from vgg19 import *
from aug_data import dataProcess
from scipy import misc, var

class MainWindow:

    def buttonListener1(self, event):
        tkinter.messagebox.showinfo("messagebox", "this is button 1 dialog")

    def buttonListener2(self, event):
        tkinter.messagebox.showinfo("messagebox", "this is button 2 dialog")

    def buttonListener3(self, event):
        if __name__ == "__main__":
            root = Toplevel()
            root.title("U-NET")  # 设置窗口标题
            canvas = Canvas(root,
                            width=950,  # 指定Canvas组件的宽度
                            height=650,  # 指定Canvas组件的高度
                            bg='white')
            # root.resizable(0, 0)
            # root.geometry("500x500")
            # root.update()
            image = Image.open('E:/code/retina/UNet.png')
            im = ImageTk.PhotoImage(image)
            canvas.create_image(490, 360, image=im)
            canvas.create_text(450, 80,  # 使用create_text方法在坐标（302，77）处绘制文字
                               text='U-Net模型结构图'  # 所绘制文字的内容
                               , fill='gray')  # 所绘制文字的颜色为灰色
            canvas.pack()  # 将Canvas添加到主窗口

            # function to be called when mouse is clicked
            def printcoords():
                # File = filedialog.askopenfilename(parent=root, initialdir="E:/code/retina/image/",title='Choose an image.')
                # filename = ImageTk.PhotoImage(Image.open(File))
                # canvas.image = filename  # <--- keep reference of your image
                # canvas.create_image(10,10,anchor='nw',image=filename)
                # print('File',File)
                # print('filename',filename)
                n = int(entry.get())
                # print(n)

                mask = Image.open('E:/code/retina/mask.tif').convert('L')
                mask_arr = np.array(mask)
                mask_otsu = np.zeros([512, 512])
                [rows, cols] = mask_arr.shape
                for i in range(rows - 1):
                    for j in range(cols - 1):
                        if mask_arr[i, j] > 125:
                            mask_otsu[i, j] = 255
                kernel = np.ones((7, 7), np.uint8)
                mask_otsu = cv2.erode(mask_otsu, kernel, iterations=2)
                mydata = dataProcess(512, 512)
                img_test = mydata.load_test_data()

                myunet = Vgg19()
                model = myunet.get_unet()
                model.load_weights('unet.hdf5')
                imgs_mask_test = model.predict(img_test, batch_size=1, verbose=1)

                np.save('imgs_mask_test.npy', imgs_mask_test)
                imgs_test_predict = np.load('imgs_mask_test.npy')
                img_test1 = np.load('imgs_test1.npy')
                # print(img_test.shape, imgs_test_predict.shape)

                img1 = imgs_test_predict[n-1]
                img1 = array_to_img(img1)
                img_arr = np.array(img1)
                img2 = img_test1[n - 1]
                img2 = array_to_img(img2)

                for i in range(rows - 1):
                    for j in range(cols - 1):
                        if mask_otsu[i, j] == 0:
                            img_arr[i, j] = 0
                # photo = PhotoImage(file='n.gif')
                # imgLabel = Label(root, image=photo)
                # imgLabel.pack(side=RIGHT)
                # plt.gray()
                # plt.imshow(img_arr)
                # plt.title("Retinal vessel segmentation")
                # plt.axis('off')
                # plt.show()
                # scipy.misc.imsave('test.tif', img_arr)
                fig = plt.figure()
                ax = fig.add_subplot(122)
                ax.imshow(img_arr, cmap="gray")  # 以灰度图显示图片
                ax.set_title("Retinal vessel segmentation")
                plt.axis('off')

                ax = fig.add_subplot(121)
                ax.imshow(img2)
                ax.set_title("Original retinal image")
                plt.axis('off')
                plt.show()

            e = StringVar()
            entry = Entry(root,
                          text='input image number here'
                          )
            entry.pack()
            # entry.bind('<Button-1>', Button)
            Button(root, text='确定', command=printcoords).pack(side=TOP)
            root.mainloop()

    def buttonListener4(self, event):
        tkinter.messagebox.showinfo("messagebox", "this is button 4 dialog")

    def __init__(self):
        self.frame = Tk()

        self.button1 = Button(self.frame, text="金吉成", width=20, height=10)
        self.button2 = Button(self.frame, text="詹金豪", width=20, height=10)
        self.button3 = Button(self.frame, text="邹义轩", width=20, height=10)
        self.button4 = Button(self.frame, text="夏冬", width=20, height=10)

        self.button1.grid(row=0, column=0, padx=10, pady=10)
        self.button2.grid(row=0, column=1, padx=10, pady=10)
        self.button3.grid(row=1, column=0, padx=10, pady=10)
        self.button4.grid(row=1, column=1, padx=10, pady=10)

        self.button1.bind("<ButtonRelease-1>", self.buttonListener1)
        self.button2.bind("<ButtonRelease-1>", self.buttonListener2)
        self.button3.bind("<ButtonRelease-1>", self.buttonListener3)
        self.button4.bind("<ButtonRelease-1>", self.buttonListener4)

        self.frame.mainloop()


window = MainWindow()

# import cv2
# import matplotlib.pyplot as plt
# from tkinter import *
# from tkinter import filedialog
# from PIL import Image, ImageTk
# import numpy as np
# from keras.preprocessing.image import array_to_img, img_to_array,load_img
# from pywin.framework import window
# from vgg19 import *
# from keras.preprocessing.image import array_to_img
# from PIL import Image
# import scipy
# import ImageTk
# from scipy import misc, var
# 
# if __name__ == "__main__":
#     root = Tk()
#     root.title("U-NET")  # 设置窗口标题
#     canvas = Canvas(root,
#                             width=950,  # 指定Canvas组件的宽度
#                             height=650,  # 指定Canvas组件的高度
#                             bg='white')
#     # root.resizable(0, 0)
#     # root.geometry("500x500")
#     # root.update()
#     image = Image.open('E:/code/retina/UNet.png')
#     im = ImageTk.PhotoImage(image)
#     canvas.create_image(480, 410, image=im)
#     canvas.create_text(450, 80,  # 使用create_text方法在坐标（302，77）处绘制文字
#                        text='U-Net模型结构图'  # 所绘制文字的内容
#                        , fill='gray')  # 所绘制文字的颜色为灰色
#     canvas.pack()  # 将Canvas添加到主窗口
# 
#     #function to be called when mouse is clicked
#     def printcoords():
#         # File = filedialog.askopenfilename(parent=root, initialdir="E:/code/retina/image/",title='Choose an image.')
#         # filename = ImageTk.PhotoImage(Image.open(File))
#         # canvas.image = filename  # <--- keep reference of your image
#         # canvas.create_image(10,10,anchor='nw',image=filename)
#         # print('File',File)
#         # print('filename',filename)
#         n = int(entry.get())
#         print(n)
# 
#         mask = Image.open('E:/code/retina/mask.tif').convert('L')
#         mask_arr = np.array(mask)
#         mask_otsu = np.zeros([512, 512])
#         [rows, cols] = mask_arr.shape
#         for i in range(rows - 1):
#             for j in range(cols - 1):
#                 if mask_arr[i, j] > 125:
#                     mask_otsu[i, j] = 255
#         kernel = np.ones((7, 7), np.uint8)
#         mask_otsu = cv2.erode(mask_otsu, kernel, iterations=2)
#         # mydata = dataProcess(512, 512)
#         # img_test = mydata.load_test_data()
# 
#         # myunet = Vgg19()
#         # model = myunet.get_unet()
#         # model.load_weights('unet.hdf5')
#         # imgs_mask_test = model.predict(img_test, batch_size=1, verbose=1)
#         #
#         # np.save('imgs_mask_test.npy', imgs_mask_test)
#         imgs_test_predict = np.load('imgs_mask_test.npy')
#         # print(img_test.shape, imgs_test_predict.shape)
# 
#         img1 = imgs_test_predict[n]
#         img1 = array_to_img(img1)
#         img_arr = np.array(img1)
# 
#         for i in range(rows - 1):
#             for j in range(cols - 1):
#                 if mask_otsu[i, j] == 0:
#                     img_arr[i, j] = 0
#         # photo = PhotoImage(file='n.gif')
#         # imgLabel = Label(root, image=photo)
#         # imgLabel.pack(side=RIGHT)
#         plt.gray()
#         plt.imshow(img_arr)
#         plt.title("Retinal vessel segmentation")
#         plt.axis('off')
#         plt.show()
#         scipy.misc.imsave('n.tif', img_arr)
# 
# 
#     e = StringVar()
#     entry = Entry(root,
#                   text='input image number here'
#                   )
#     entry.pack()
#     # entry.bind('<Button-1>', Button)
#     Button(root,text='确定',command=printcoords).pack(side=TOP)
#     root.mainloop()
