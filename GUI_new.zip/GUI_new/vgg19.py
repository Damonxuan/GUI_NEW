import time
from keras.models import *
from keras.layers import Input,normalization,Conv2D, MaxPooling2D, UpSampling2D,Dropout,Conv2DTranspose,BatchNormalization,concatenate,Activation,Lambda
from keras.optimizers import *
from keras.callbacks import ModelCheckpoint,TensorBoard
from aug_data import dataProcess
from keras.layers.merge import add,multiply



class Vgg19:
    def __init__(self,img_rows=512, img_cols=512):

        self.img_rows = img_rows
        self.img_cols = img_cols


    def load_data(self):
            mydata = dataProcess( self.img_rows, self.img_cols )
            imgs_train, imgs_mask_train = mydata.load_train_data()
            return imgs_train, imgs_mask_train


    def expend_as(self, tensor, rep):
        my_repeat = Lambda(lambda x, repnum: K.repeat_elements(x, repnum, axis=3), arguments={'repnum': rep})(tensor)
        return my_repeat


    def AttnGatingBlock(self, x, g, inter_shape):
        shape_x = K.int_shape(x)  # 32
        shape_g = K.int_shape(g)  # 16

        theta_x = Conv2D(inter_shape, (2, 2), strides=(2, 2), padding='same')(x)  # 16
        shape_theta_x = K.int_shape(theta_x)

        phi_g = Conv2D(inter_shape, (1, 1), padding='same')(g)
        upsample_g = Conv2DTranspose(inter_shape, (3, 3),
                                     strides=(shape_theta_x[1] // shape_g[1], shape_theta_x[2] // shape_g[2]),
                                     padding='same')(phi_g)  # 16

        concat_xg = add([upsample_g, theta_x])
        act_xg = Activation('relu')(concat_xg)
        psi = Conv2D(1, (1, 1), padding='same')(act_xg)
        sigmoid_xg = Activation('sigmoid')(psi)
        shape_sigmoid = K.int_shape(sigmoid_xg)
        upsample_psi = UpSampling2D(size=(shape_x[1] // shape_sigmoid[1], shape_x[2] // shape_sigmoid[2]))(
            sigmoid_xg)  # 32


        upsample_psi = self.expend_as(upsample_psi, shape_x[3])

        y = multiply([upsample_psi, x])

        # print(K.is_keras_tensor(upsample_psi))

        result = Conv2D(shape_x[3], (1, 1), padding='same')(y)
        result_bn = BatchNormalization()(result)
        return result_bn


    def UnetGatingSignal(self, input, is_batchnorm=False):
        shape = K.int_shape(input)
        x = Conv2D(shape[3] * 2, (1, 1), strides=(1, 1), padding="same")(input)
        if is_batchnorm:
            x = BatchNormalization()(x)
        x = Activation('relu')(x)
        return x


    def DenseBlock(self, inputs, outdim):

        inputshape = K.int_shape(inputs)
        bn = normalization.BatchNormalization(epsilon=2e-05, axis=1, momentum=0.9, weights=None,
                                              beta_initializer='zero', gamma_initializer='one')(inputs)
        act = Activation('relu')(bn)
        conv1 = Conv2D(outdim, (3, 3), activation=None, padding='same')(act)

        if inputshape[1] != outdim:
            shortcut = Conv2D(outdim, (1, 1), padding='same')(inputs)
        else:
            shortcut = inputs
        result1 = add([conv1, shortcut])

        bn = normalization.BatchNormalization(epsilon=2e-05, axis=1, momentum=0.9, weights=None,
                                              beta_initializer='zero', gamma_initializer='one')(result1)
        act = Activation('relu')(bn)
        conv2 = Conv2D(outdim, (3, 3), activation=None, padding='same')(act)
        result = add([result1, conv2, shortcut])
        result = Activation('relu')(result)
        return result


    def get_unet(self):
        inputs = Input((self.img_rows, self.img_cols, 1))
        print("inputs shape:",inputs.shape)
        print("build model started")
        conv1 = Conv2D(3, 3, activation='relu', padding='same', kernel_initializer='he_normal')(inputs)
        conv1_1 = Conv2D(64, 3, activation='relu', padding='same', name = 'block1_conv1')(conv1)
        conv1_2 = Conv2D(64, 3, activation='relu', padding='same', name = 'block1_conv2')(conv1_1)
        conv1_2 = normalization.BatchNormalization(epsilon=2e-05, axis=1, momentum=0.9, weights=None,
                                                 beta_initializer='zero', gamma_initializer='one')(conv1_2)
        conv1_3 = self.DenseBlock(conv1_2, 64)
        pool1 = MaxPooling2D(pool_size=(2, 2),name = 'block1_pool')(conv1_3)
        print("pool1 shape:", pool1.shape)

        conv2_1 = Conv2D(128, 3, activation='relu', padding='same', name = 'block2_conv1')(pool1)
        conv2_2 = Conv2D(128, 3, activation='relu', padding='same', name = 'block2_conv2')(conv2_1)
        conv2_3 = self.DenseBlock(conv2_2, 128)
        pool2 = MaxPooling2D(pool_size=(2, 2),name = 'block2_pool')(conv2_3)
        print("pool2 shape:", pool2.shape)

        conv3_1 = Conv2D(256, 3, activation='relu', padding='same', name = 'block3_conv1')(pool2)
        conv3_2 = Conv2D(256, 3, activation='relu', padding='same', name = 'block3_conv2')(conv3_1)
        conv3_3 = Conv2D(256, 3, activation='relu', padding='same', name = 'block3_conv3')(conv3_2)
        conv3_4 = Conv2D(256, 3, activation='relu', padding='same', name='block3_conv4')(conv3_3)
        conv3_5 = self.DenseBlock(conv3_4, 256)
        pool3 = MaxPooling2D(pool_size=(2, 2),name = 'block3_pool')(conv3_5)
        print("pool3 shape:", pool3.shape)

        conv4_1 = Conv2D(512, 3, activation='relu', padding='same', name = 'block4_conv1')(pool3)
        conv4_2 = Conv2D(512, 3, activation='relu', padding='same', name = 'block4_conv2')(conv4_1)
        conv4_3 = Conv2D(512, 3, activation='relu', padding='same', name = 'block4_conv3')(conv4_2)
        conv4_4 = Conv2D(512, 3, activation='relu', padding='same', name='block4_conv4')(conv4_3)
        conv4_5 = self.DenseBlock(conv4_4, 512)
        # drop4 = Dropout(0.5)(conv4_5)
        pool4 = MaxPooling2D(pool_size=(2, 2),name = 'block4_pool')(conv4_5)
        print("pool4 shape:", pool4.shape)

        conv5_1 = Conv2D(512, 3, activation='relu', padding='same', name = 'block5_conv1')(pool4)
        conv5_2 = Conv2D(512, 3, activation='relu', padding='same', name = 'block5_conv2')(conv5_1)
        conv5_3 = Conv2D(512, 3, activation='relu', padding='same', name = 'block5_conv3')(conv5_2)
        conv5_4 = Conv2D(512, 3, activation='relu', padding='same', name='block5_conv4')(conv5_3)
        conv5_5 = self.DenseBlock(conv5_4, 512)
        # drop5 = Dropout(0.5)(conv5_5)
        pool5 = MaxPooling2D(pool_size=(2, 2),name = 'block5_pool')(conv5_5)
        print("pool5 shape:", pool5.shape)


        conv = Conv2D( 512, 3, activation='relu', padding='same', kernel_initializer='he_normal' )( pool5 )
        # gating_1 = self.UnetGatingSignal(conv, is_batchnorm=True)
        gating = self.UnetGatingSignal(conv, is_batchnorm=True)
        attn_1 = self.AttnGatingBlock(conv5_5, gating, 512)
        # up6 = Conv2D( 256, 2, activation='relu', padding='same', kernel_initializer='he_normal' )(
        #     UpSampling2D( size=(2, 2) )( conv ) )
        # merge6 = merge( [conv5_3, up6], mode='concat', concat_axis=3 )
        up1 = concatenate([Conv2DTranspose(256, (3, 3), strides=(2, 2), padding='same')(conv), attn_1], axis=3)
        conv6_1 = Conv2D( 512, 3, activation='relu', padding='same', kernel_initializer='he_normal' )( up1 )
        conv6_2 = Conv2D( 512, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv6_1)
        print( "conv6_2 shape:", conv6_2.shape )

        # up7 = Conv2D( 256, 2, activation='relu', padding='same', kernel_initializer='he_normal' )(
        #     UpSampling2D( size=(2, 2) )( conv6 ) )
        # merge7 = merge( [conv4_3, up7], mode='concat', concat_axis=3 )
        # conv7 = Conv2D( 256, 3, activation='relu', padding='same', kernel_initializer='he_normal' )( merge7 )
        # gating_2 = self.UnetGatingSignal(conv6_2, is_batchnorm=True)
        attn_2 = self.AttnGatingBlock(conv4_5, gating, 512)
        up2 = concatenate([Conv2DTranspose(256, (3, 3), strides=(2, 2), padding='same')(conv6_2), attn_2], axis=3)
        conv7_1 = Conv2D( 256, 3, activation='relu', padding='same', kernel_initializer='he_normal')(up2)
        conv7_2 = Conv2D(256, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv7_1)
        print( "conv7_2 shape:", conv7_2.shape )

        # up8 = Conv2D( 128, 2, activation='relu', padding='same', kernel_initializer='he_normal' )(
        #     UpSampling2D( size=(2, 2) )( conv7 ) )
        # merge8 = merge( [conv3_3, up8], mode='concat', concat_axis=3 )
        # conv8 = Conv2D( 128, 3, activation='relu', padding='same', kernel_initializer='he_normal' )( merge8 )
        # gating_3 = self.UnetGatingSignal(conv7_2, is_batchnorm=True)
        attn_3 = self.AttnGatingBlock(conv3_5, gating, 256)
        up3 = concatenate([Conv2DTranspose(128, (3, 3), strides=(2, 2), padding='same')(conv7_2), attn_3], axis=3)
        conv8_1 = Conv2D( 128, 3, activation='relu', padding='same', kernel_initializer='he_normal')(up3)
        conv8_2 = Conv2D(128, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv8_1)
        print( "conv8_2 shape:", conv8_2.shape )

        # up9 = Conv2D( 64, 2, activation='relu', padding='same', kernel_initializer='he_normal' )(
        #     UpSampling2D( size=(2, 2) )( conv8 ) )
        # merge9 = merge( [conv2_2, up9], mode='concat', concat_axis=3 )
        # conv9 = Conv2D( 64, 3, activation='relu', padding='same', kernel_initializer='he_normal' )( merge9 )
        # gating_4 = self.UnetGatingSignal(conv8_2, is_batchnorm=True)
        attn_4 = self.AttnGatingBlock(conv2_3, gating, 128)
        up4 = concatenate([Conv2DTranspose(64, (3, 3), strides=(2, 2), padding='same')(conv8_2), attn_4], axis=3)
        conv9_1 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(up4)
        conv9_2 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv9_1)
        print( "conv9_2 shape:", conv9_2.shape )

        # up10 = Conv2D( 32, 2, activation='relu', padding='same', kernel_initializer='he_normal' )(
        #     UpSampling2D( size=(2, 2) )( conv9 ) )
        # merge10 = merge( [conv1_2, up10], mode='concat', concat_axis=3 )
        # conv10 = Conv2D( 32, 3, activation='relu', padding='same', kernel_initializer='he_normal' )( merge10 )
        # gating_5 = self.UnetGatingSignal(conv9_2, is_batchnorm=True)
        attn_5 = self.AttnGatingBlock(conv1_3, gating, 64)
        up5 = concatenate([Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(conv9_2), attn_5], axis=3)
        conv10_1 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(up5)
        conv10_2 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')(conv10_1)
        conv10_3 = Conv2D(1, 1, activation='sigmoid' )( conv10_2 )

        model = Model( inputs=inputs, outputs=conv10_3 )
        model.load_weights('E:/code/retina/vgg19_weights_tf_dim_ordering_tf_kernels.h5',by_name=True)
        print("load_weights down")

        model.compile( optimizer=Adam( lr=1e-4 ), loss='binary_crossentropy', metrics=['accuracy'] )
        print( 'model compile' )
        return model

    def train(self):
        print("loading data")
        imgs_train, imgs_mask_train = self.load_data()
        print("loading data done")
        model = self.get_unet()
        print("got unet")

        # 保存的是模型和权重
        model_checkpoint = ModelCheckpoint('unet.hdf5', monitor='loss', verbose=1, save_best_only=True)
        print('Fitting model...')
        model.fit(imgs_train, imgs_mask_train, batch_size=2, epochs=30, verbose=1, shuffle=True,
                  callbacks=[model_checkpoint,TensorBoard('./logs')])
        # mydata = dataProcess( 512, 512 )
        # img_test = mydata.load_test_data()
        # print('predict test data')
        # imgs_mask_test = model.predict(img_test, batch_size=1, verbose=1)
        # np.save('imgs_mask_test.npy', imgs_mask_test)


if __name__ == '__main__':
    time_to_start = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime(time.time()))
    myunet = Vgg19()
    myunet.train()
    time_to_end = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime(time.time()))
    print(time_to_start)
    print(time_to_end)
